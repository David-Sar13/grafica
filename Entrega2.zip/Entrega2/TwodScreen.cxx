// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep,we got a pseudo-model for the screen in TwoD
// ----------------------------------------------------------------------------

#include "TwodScreen.h"

// ----------------------------------------------------------------------------
TwodScreen::TwodScreen( )
{
}

// ----------------------------------------------------------------------------
TwodScreen::~TwodScreen( )
{
}

// ----------------------------------------------------------------------------
void TwodScreen::SetId( int id )
{
    this->id = id;
}

// ----------------------------------------------------------------------------
void TwodScreen::SetQuadQ( int quadQ )
{
    this->quadQ = quadQ;
}

// ----------------------------------------------------------------------------
void TwodScreen::SetColorP( float a, float b, float c )
{
    this->colorP.push_back( a );
    this->colorP.push_back( b );
    this->colorP.push_back( c );
}

// ----------------------------------------------------------------------------
void TwodScreen::SetScreen( std::vector< float > quads, std::vector< float > quadC, std::vector< int > sendTo, std::vector< std::string > quadsText )
{
    this->quads = quads;
    this->quadC = quadC;
    this->sendTo = sendTo;
    this->quadsText = quadsText;
}
// ----------------------------------------------------------------------------
int TwodScreen::getId( )
{
    return this->id;
}
// ----------------------------------------------------------------------------
int TwodScreen::getIQuadQ( )
{
    return this->quadQ;
}

// ----------------------------------------------------------------------------
std::vector< float > TwodScreen::getColorP( )
{
    return this->colorP;
}

// ----------------------------------------------------------------------------
std::vector< float > TwodScreen::getQuads( )
{
    return this->quads;
}

// ----------------------------------------------------------------------------
std::vector< float > TwodScreen::getQuadC( )
{
    return this->quadC;
}

// ----------------------------------------------------------------------------
std::vector< std::string > TwodScreen::getQuadsText( )
{
    return this->quadsText;
}

// ----------------------------------------------------------------------------
int TwodScreen::searchSender( int xDo, int yDo, int xUp, int yUp )
{
    int senderId = 0;
    xDo /= 10;
    yDo /= 10;
    xUp /= 10;
    yUp /= 10;
    for( int i = 0 ; i < quads.size( ) ; i += 4 )
    {
        if( xDo > this->quads[ i ] && xDo < this->quads[ i + 1 ] && xUp > this->quads[ i ] && xUp < this->quads [ i + 1 ] )
        {
            if( yDo > this->quads[ i +2 ] && yDo < this->quads[ i + 3 ] && yUp > this->quads[ i + 2 ] && yUp < this->quads[ i + 3 ]  )
            {
                return this->sendTo[ senderId ];
            }
        }
        ++senderId;
    }
    return -1;
}
