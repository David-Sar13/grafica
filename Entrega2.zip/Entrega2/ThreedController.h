// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief o, here is the controller for the game itself
// ----------------------------------------------------------------------------

#ifndef __ThreedController__h__
#define __ThreedController__h__

#include <GL/glut.h>
#include <bits/stdc++.h>
#include "ThreedLevel.h"

// ----------------------------------------------------------------------------
class ThreedController
{
public:
    ThreedController( );
    virtual ~ThreedController( );

    void DrawRoom( std::vector< float > sizeL, std::vector< float > colorF );
    void launchLevel( int id );
    void receive( std::vector< std::vector < std::string > > dataF );
    std::vector< float > calculate( int id );
    std::vector< float > calculateDos( int id, int option, int state );
    void sendFruit( int id );
    void DrawCube( );
    void DisplayRound( int id );
    void setSnake( int id );
    void drawSnake( int id );
    int moveDaWorm( int id, int state );

protected:
    std::vector< ThreedLevel > levels;

};

#endif
