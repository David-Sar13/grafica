// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep, here lays the structure for each level of the game
// ----------------------------------------------------------------------------

#include "ThreedLevel.h"

// ----------------------------------------------------------------------------
ThreedLevel::ThreedLevel( )
{
}

// ----------------------------------------------------------------------------
ThreedLevel::~ThreedLevel( )
{
}

// ----------------------------------------------------------------------------
void ThreedLevel::setId( int id )
{
    this->id = id;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setColorF( std::vector< float > colorF )
{
    this->colorF = colorF;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setSizeL( std::vector< float > sizeL )
{
    this->sizeL = sizeL;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setPosSnake( std::vector < std::vector < float > > posSnake )
{
    this->posSnake = posSnake;
}

// ----------------------------------------------------------------------------
void ThreedLevel::setPosFruits( std::vector < std::vector < float > > posFruits )
{
    this->posFruits = posFruits;
}

// ----------------------------------------------------------------------------
int ThreedLevel::getId( )
{
    return this->id;
}

// ----------------------------------------------------------------------------
std::vector < float > ThreedLevel::getColorF( )
{
    return this->colorF;
}
// ----------------------------------------------------------------------------
std::vector < float > ThreedLevel::getSizeL( )
{
    return this->sizeL;
}
// ----------------------------------------------------------------------------
std::vector < std::vector < float > > ThreedLevel::getPosSnake( )
{
    return this->posSnake;
}
// ----------------------------------------------------------------------------
std::vector < std::vector < float > > ThreedLevel::getPosFruits( )
{
    return this->posFruits;
}
// ----------------------------------------------------------------------------
int ThreedLevel::modifyOne( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 0 ] + 1 ) < sizeL[ 0 ] )
    {
        this->posSnake.pop_back( );
        temp[ 0 ] += 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyTwo( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 0 ] - 1 ) > 0 )
    {
        this->posSnake.pop_back( );
        temp[ 0 ] -= 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyThree( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 2 ] + 1 ) < sizeL[ 0 ] )
    {
        this->posSnake.pop_back( );
        temp[ 2 ] += 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
int ThreedLevel::modifyFour( )
{
    std::vector < float > temp = this->posSnake[ 0 ];
    if( ( temp[ 2 ] - 1 ) > 0 )
    {
        this->posSnake.pop_back( );
        temp[ 2 ] -= 1;
        this->posSnake.insert( posSnake.begin( ), temp );
    }
    else
    {
        return 1;
    }
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
