// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep, here lays the structure for each level of the game
// ----------------------------------------------------------------------------

#ifndef __ThreedLevel__h__
#define __ThreedLevel__h__

#include <GL/glut.h>
#include <bits/stdc++.h>

// ----------------------------------------------------------------------------
class ThreedLevel
{
public:
    ThreedLevel( );
    virtual ~ThreedLevel( );

    void setId( int id );
    void setColorF( std::vector< float > colorF );
    void setSizeL( std::vector< float > sizeL );
    void setPosSnake( std::vector < std::vector < float > > posSnake );
    void setPosFruits( std::vector < std::vector < float > > posFruits );

    int getId( );
    std::vector < float > getColorF( );
    std::vector < float > getSizeL( );
    std::vector < std::vector < float > > getPosSnake( );
    std::vector < std::vector < float > > getPosFruits( );

    int modifyOne( );
    int modifyTwo( );
    int modifyThree( );
    int modifyFour( );


protected:
    int id;
    std::vector < float > colorF;
    std::vector < float > sizeL;
    std::vector < std::vector < float > > posSnake;
    std::vector < std::vector < float > > posFruits;

};

#endif
