// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief o, here is the controller for the game itself
// ----------------------------------------------------------------------------

#ifndef __ThreedController__h__
#define __ThreedController__h__

#include <GL/glut.h>
#include <bits/stdc++.h>
#include "ThreedLevel.h"

// ----------------------------------------------------------------------------
class ThreedController
{
public:
    ThreedController( );
    virtual ~ThreedController( );

    void DrawRoom( std::vector< float > sizeL, std::vector< float > colorF );
    void launchLevel( int id );
    void receive( std::vector< std::vector < std::string > > dataF );
    std::vector< float > calculate( int id );
    std::vector< float > calculateDos( int id, int option, int state );
    int sendFruit( int id, int time, int state );
    void DrawCube( );
    void DrawFruit( );
    void DrawObstacle( );
    void DisplayRound( int id );
    void setSnake( int id );
    void drawSnake( int id );
    int moveDaWorm( int id, int state );
    int check( int id, int time, int state );
    void increment( int id, int state );
    void setLevelDiff( int id, int diff );
    void prepareObstacles( int id );

protected:
    std::vector< ThreedLevel > levels;

};

#endif
