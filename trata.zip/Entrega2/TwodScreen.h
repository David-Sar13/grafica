// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief Yep,we got a pseudo-model for the screen in TwoD
// ----------------------------------------------------------------------------

#ifndef __TwodScreen__h__
#define __TwodScreen__h__

#include <GL/glut.h>
#include <bits/stdc++.h>

// ----------------------------------------------------------------------------
class TwodScreen
{
public:
    TwodScreen( );
    virtual ~TwodScreen( );

    void SetId( int id);
    void SetQuadQ( int quadQ );
    void SetColorP( float a, float b, float c );
    void setQuadsText( std::vector< std::string > quadsText );
    void SetScreen( std::vector< float > quads, std::vector< float > quadC, std::vector< int > sendTo,  std::vector< std::string > quadsText );

    int getId( );
    int getIQuadQ( );
    std::vector< float > getColorP( );
    std::vector< float > getQuads( );
    std::vector< float > getQuadC( );
    std::vector< std::string > getQuadsText( );

    std::pair< int, int > searchSender( int xDo, int yDo, int xUp, int yUp );

protected:
    int id;
    int quadQ;
    std::vector< float > colorP;
    std::vector< float > quads;
    std::vector< float > quadC;
    std::vector< std::string > quadsText;
    std::vector< int > sendTo;

};

#endif
