// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief So, this is our controller for Twod Screens
// ----------------------------------------------------------------------------

#ifndef __TwodController__h__
#define __TwodController__h__

#include <GL/glut.h>
#include <bits/stdc++.h>
#include "TwodScreen.h"

// ----------------------------------------------------------------------------
class TwodController
{
public:
    TwodController( );
    virtual ~TwodController( );

    //Launch the Twod Main Set
    void receive( std::vector< std::vector< std::string > > dataF );
    void start( int id );
    void drawScreen( int id );
    void DrawSquare( GLenum mode );
    void Listener( int button, int state, int x, int y );
    std::pair< int, int > checkFor2d( int xDo, int yDo, int xUp, int yUp, int id );
    void outPut( float x, float y, std::string text );
    void setScore( int score );

protected:
    std::vector < TwodScreen > screens;

};

#endif
