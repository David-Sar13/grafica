// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief o, here is the controller for the game itself
// ----------------------------------------------------------------------------

#include "ThreedController.h"

// ----------------------------------------------------------------------------
ThreedController::ThreedController( )
{
}

// ----------------------------------------------------------------------------
ThreedController::~ThreedController( )
{
}

// ----------------------------------------------------------------------------
void ThreedController::DrawRoom( std::vector< float > sizeL, std::vector< float > colorF )
{
    int auxInt = 0;

    float points[ 8 ][ 3 ] =
    {
        { -0.5, -0.5, -0.5 },
        { 0.5, -0.5, -0.5 },
        { 0.5, -0.5, 0.5 },
        { -0.5, -0.5, 0.5 },
        { -0.5, 0.5, -0.5 },
        { 0.5, 0.5, -0.5 },
        { 0.5, 0.5, 0.5 },
        { -0.5, 0.5, 0.5 }
    };

    unsigned int faces[ 6 ][ 4 ] =
    {
        { 1, 5, 4, 0 },
        { 2, 6, 5, 1 },
        { 0, 3, 2, 1 },
        { 0, 4, 7, 3 },
        { 6, 2, 3, 7 },
        { 4, 5, 6, 7 }

    };
    for( unsigned int i = 0; i < 6; ++i )
    {
        //glColor3f( colorF[ auxInt ], colorF[ auxInt + 1 ], colorF[ auxInt + 2 ] );
        auxInt += 3;
        glBegin( GL_POLYGON );
        {
            for( unsigned int j = 0; j < 4; ++j )
            {
                glColor3f( colorF[ auxInt ], colorF[ auxInt + 1 ], colorF[ auxInt + 2 ] );
                glNormal3fv( points[ faces[ i ][ j ] ] );
                glVertex3fv( points[ faces[ i ][ j ] ] );
            }
        }
        glEnd( );
    }
}
// ----------------------------------------------------------------------------
void ThreedController::DrawCube( )
{
    float colors[ 8 ][ 3 ] =
    {
      { 0.5, 1, 0.7 },
      { 0.3, 0.8, 0.0 },
      { 0.5, 1, 0.3 },
      { 0.5, 1, 0.8 },
      { 0.5, 1, 0.0 },
      { 1, 0.7, 0.3 },
      { 1, 0.3, 0.5 },
      { 0.7, 0.3, 0.8 }
    };

    float points[ 8 ][ 3 ] =
    {
      { 0, 0, 0 },
      { 1, 0, 0 },
      { 0, 0, 1 },
      { 1, 0, 1 },
      { 0, 1, 0 },
      { 0, 1, 1 },
      { 1, 1, 0 },
      { 1, 1, 1 }
    };

    unsigned int faces[ 6 ][ 4 ] =
    {
      { 0, 1, 3, 2 },
      { 0, 2, 5, 4 },
      { 2, 3, 7, 5 },
      { 5, 7, 6, 4 },
      { 1, 6, 7, 3 },
      { 1, 0, 4, 6 }
    };
    for( unsigned int i = 0; i < 6; ++i )
    {
      glBegin( GL_POLYGON );
      {
        for( unsigned int j = 0; j < 4; ++j )
        {
          glColor3fv( colors[ faces[ i ][ j ] ] );
          glNormal3fv( points[ faces[ i ][ j ] ] );
          glVertex3fv( points[ faces[ i ][ j ] ] );
        } // end for
      }
      glEnd( );
    }
}

// ----------------------------------------------------------------------------
void ThreedController::DrawFruit( )
{
    float colors[ 8 ][ 3 ] =
    {
      { 0.5, 1, 0.7 },
      { 0.3, 0.8, 0.2 },
      { 0.6, 1, 0.3 },
      { 0.5, 0.3, 0.8 },
      { 0.4, 0.8, 0.0 },
      { 1, 0.7, 0.3 },
      { 0.7, 0.8, 0.5 },
      { 0.7, 0.3, 0.8 }
    };

    float points[ 8 ][ 3 ] =
    {
      { 0, 0, 0 },
      { 1, 0, 0 },
      { 0, 0, 1 },
      { 1, 0, 1 },
      { 0, 1, 0 },
      { 0, 1, 1 },
      { 1, 1, 0 },
      { 1, 1, 1 }
    };

    unsigned int faces[ 6 ][ 4 ] =
    {
      { 0, 1, 3, 2 },
      { 0, 2, 5, 4 },
      { 2, 3, 7, 5 },
      { 5, 7, 6, 4 },
      { 1, 6, 7, 3 },
      { 1, 0, 4, 6 }
    };
    for( unsigned int i = 0; i < 6; ++i )
    {
      glBegin( GL_POLYGON );
      {
        for( unsigned int j = 0; j < 4; ++j )
        {
          glColor3fv( colors[ faces[ i ][ j ] ] );
          glNormal3fv( points[ faces[ i ][ j ] ] );
          glVertex3fv( points[ faces[ i ][ j ] ] );
        } // end for
      }
      glEnd( );
    }
}

// ----------------------------------------------------------------------------
void ThreedController::DrawObstacle( )
{
    float colors[ 8 ][ 3 ] =
    {
      { 1, 1, 1 },
      { 1, 1, 1 },
      { 0, 0, 1 },
      { 0, 0, 1 },
      { 0, 0, 1 },
      { 0, 0, 1 },
      { 1, 1, 1 },
      { 1, 1, 1 }
    };

    float points[ 8 ][ 3 ] =
    {
      { 0, 0, 0 },
      { 1, 0, 0 },
      { 0, 0, 1 },
      { 1, 0, 1 },
      { 0, 1, 0 },
      { 0, 1, 1 },
      { 1, 1, 0 },
      { 1, 1, 1 }
    };

    unsigned int faces[ 6 ][ 4 ] =
    {
      { 0, 1, 3, 2 },
      { 0, 2, 5, 4 },
      { 2, 3, 7, 5 },
      { 5, 7, 6, 4 },
      { 1, 6, 7, 3 },
      { 1, 0, 4, 6 }
    };
    for( unsigned int i = 0; i < 6; ++i )
    {
      glBegin( GL_POLYGON );
      {
        for( unsigned int j = 0; j < 4; ++j )
        {
          glColor3fv( colors[ faces[ i ][ j ] ] );
          glNormal3fv( points[ faces[ i ][ j ] ] );
          glVertex3fv( points[ faces[ i ][ j ] ] );
        } // end for
      }
      glEnd( );
    }
}

// ----------------------------------------------------------------------------
void ThreedController::launchLevel( int id )
{
    std::vector< float > sizeL;
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            sizeL = levels[ i ].getSizeL( );
            glPushMatrix( );
            glTranslatef( sizeL[ 0 ] / 2, sizeL[ 1 ] / 2, sizeL[ 2 ] / 2 );
            glScalef( sizeL[ 0 ], sizeL[ 1 ], sizeL[ 2 ] );
            DrawRoom( levels[ i ].getSizeL( ), levels[ i ].getColorF( ) );
            glPushMatrix( );

            std::vector< std::vector < float > > auxObstacles = levels[ i ].getObstacles( );
            for( int i = 0 ; i < auxObstacles.size( ) ; ++i )
            {
                glPushMatrix( );
                glTranslatef( auxObstacles[ i ][ 0 ], auxObstacles[ i ][ 1 ], auxObstacles[ i ][ 2 ] );
                DrawObstacle( );
                glPopMatrix( );
            }
            return;
        }
    }
}
// ----------------------------------------------------------------------------
void ThreedController::receive( std::vector< std::vector < std::string > > dataF )
{
    for( int i = 0 ; i < dataF.size( ) ; ++i )
    {
        std::vector < float > colorF;
        std::vector < float > sizeL;
        ThreedLevel aux;

        aux.setId( std::stoi( dataF[ i ][ 0 ] ) );

        for( int j = 0 ; j < 18 ; j += 3 )
        {
            colorF.push_back( std::stof( dataF[ i ][ j + 1 ] ) );
            colorF.push_back( std::stof( dataF[ i ][ j + 2 ] ) );
            colorF.push_back( std::stof( dataF[ i ][ j + 3 ] ) );
        }
        aux.setColorF( colorF );

        sizeL.push_back( std::stof( dataF[ i ][ 19 ] ) );
        sizeL.push_back( std::stof( dataF[ i ][ 20 ] ) );
        sizeL.push_back( std::stof( dataF[ i ][ 21 ] ) );
        aux.setSizeL( sizeL );

        levels.push_back( aux );
        colorF.clear( );
        sizeL.clear( );
    }
}

// ----------------------------------------------------------------------------
std::vector< float > ThreedController::calculate( int id )
{
    std::vector< float > cam;
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            std::vector< float > aux = levels[ i ].getSizeL( );
            glTranslatef( aux[ 0 ] / 2, 0, aux[ 2 ] / 2  );
            cam.push_back( aux[ 0 ] / 2 );
            cam.push_back( aux[ 1 ] - 1 );
            cam.push_back( -50 );
            cam.push_back( aux[ 0 ] / 2 );
            cam.push_back( 0 );
            cam.push_back( aux[ 2 ] / 2 );

            glScalef( aux[ 0 ], aux[ 1 ], aux[ 2 ] );
            setSnake( i );
            return cam;
        }
    }
}

// ----------------------------------------------------------------------------
std::vector< float > ThreedController::calculateDos( int id, int option, int state )
{
    std::vector< float > cam;
    if( option == 0 )
    {
        for( int i = 0 ; i < levels.size( ) ; ++i )
        {
            if( levels[ i ].getId( ) == id )
            {
                std::vector< float > aux = levels[ i ].getSizeL( );
                glTranslatef( aux[ 0 ] / 2, 0, aux[ 2 ] / 2  );

                cam.push_back( aux[ 0 ] / 2 );
                cam.push_back( aux[ 1 ] - 1 );
                cam.push_back( -50 );
                cam.push_back( aux[ 0 ] / 2 );
                cam.push_back( 0 );
                cam.push_back( aux[ 2 ] / 2 );

                glScalef( aux[ 0 ], aux[ 1 ], aux[ 2 ] );

                return cam;
            }
        }
    }
    else if( option == 1 )
    {
        for( int i = 0 ; i < levels.size( ) ; ++i )
        {
            if( levels[ i ].getId( ) == id )
            {
                std::vector< float > aux = levels[ i ].getSizeL( );
                glTranslatef( aux[ 0 ] / 2, 0, aux[ 2 ] / 2  );

                std::vector < std::vector < float > > aux2 = levels[ i ].getPosSnake( );
                std::vector < float > auxReal = aux2[ 0 ];

                cam.push_back( auxReal[ 0 ] + 0.51 );
                cam.push_back( 0.5 );
                cam.push_back( auxReal[ 2 ] + 0.51 );
                if( state == 3 )
                {
                    cam.push_back( auxReal[ 0 ] );
                    cam.push_back( 0.5 );
                    cam.push_back( aux[ 2 ] );
                }
                else if( state == 2 )
                {
                    cam.push_back( 0 );
                    cam.push_back( 0.5 );
                    cam.push_back( auxReal[ 2 ] );
                }
                else if( state == 1 )
                {
                    cam.push_back( aux[ 0 ] );
                    cam.push_back( 0.5 );
                    cam.push_back( auxReal[ 2 ] );
                }
                else if( state == 4 )
                {
                    cam.push_back( auxReal[ 2 ] );
                    cam.push_back( 0.5 );
                    cam.push_back( 0 );
                }

                glScalef( aux[ 0 ], aux[ 1 ], aux[ 2 ] );

                return cam;
            }
        }
    }
}

// ----------------------------------------------------------------------------
void ThreedController::DisplayRound( int id )
{
    drawSnake( id );
}

// ----------------------------------------------------------------------------
void ThreedController::setSnake( int id )
{
    std::vector < std::vector < float > > snake;
    std::vector < float > snakeUn;
    std::vector < float > sizeL = levels[ id ].getSizeL( );

    for( int i = 0; i < 3 ; ++i )
    {
        snakeUn.push_back( sizeL[ 0 ] / 2 );
        snakeUn.push_back( 0 );
        snakeUn.push_back( ( sizeL[ 2 ] / 2 ) - i );

        snake.push_back( snakeUn );
        snakeUn.clear( );
    }

    levels[ id ].setPosSnake( snake );
}

// ----------------------------------------------------------------------------
void ThreedController::drawSnake( int id )
{
    std::vector < std::vector < float > > snake;
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            snake = levels[ i ].getPosSnake( );
            for( int j = 0 ; j < snake.size( ) ; ++j )
            {
                glPushMatrix( );
                glTranslatef( snake[ j ][ 0 ] - 0.5, 0, snake[ j ][ 2 ] - 0.5 );
                DrawCube( );
                glPopMatrix( );
            }
        }
    }
}
// ----------------------------------------------------------------------------
std::pair< int, int > ThreedController::moveDaWorm( int id, int state )
{
    int aux = 0;
    std::pair< int, int > auxPair;
    auxPair.first = 0;
    auxPair.second = 0;
    // left -> 1
    // right -> 2
    // front -> 3
    // back -> 4
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            if( state == 1 )
            {
                auxPair.first = levels[ i ].modifyOne( );
            }
            if( state == 2 )
            {
                auxPair.first = levels[ i ].modifyTwo( );
            }
            if( state == 3 )
            {
                auxPair.first = levels[ i ].modifyThree( );
            }
            if( state == 4 )
            {
                auxPair.first = levels[ i ].modifyFour( );
            }
            auxPair.second = levels[ i ].getScore( );
        }
    }
    return auxPair;
}
// ----------------------------------------------------------------------------
int ThreedController::sendFruit( int id, int time, int state )
{
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            if( time == 1 )
            {
                std::vector< std::vector < float > > auxFruits;
                std::vector< float > tam = levels[ i ].getSizeL( );
                std::vector< float > posFruit;
                std::vector < std::vector < float > > auxSnake = levels[ i ].getPosSnake( );
                bool state = false;
                float posX = rand( ) % ( int )tam[ 0 ];
                float posY = 0;
                float posZ = rand( ) % ( int )tam[ 2 ];
                for( int i = 0 ; i < auxSnake.size( ) ; ++i )
                {
                    if( posX == auxSnake[ i ][ 0 ] && posY == auxSnake[ i ][ 1 ] && posZ == auxSnake[ i ][ 2 ] )
                    {
                        state = true;
                    }
                }
                posFruit.push_back( posX );
                posFruit.push_back( posY );
                posFruit.push_back( posZ );
                auxFruits.push_back( posFruit );
                levels[ i ].setPosFruits( auxFruits );
                return time;
            }
            if( time > 1 && time < 400 )
            {
                time = check( i, time, state );
                if( time > 0 )
                {
                    std::vector< std::vector < float > > auxFruits = levels[ i ].getPosFruits( );
                    glPushMatrix( );
                    glTranslatef( auxFruits[ 0 ][ 0 ], auxFruits[ 0 ][ 1 ], auxFruits[ 0 ][ 2 ] );
                    //glScalef( 3000, 3000, 3000 );
                    DrawFruit( );
                    glPopMatrix( );
                    return time;
                }
            }
            //300
            if( time == 400 )
            {
                return 0;
            }
        }
    }
    return 0;
}
// ----------------------------------------------------------------------------
int ThreedController::check( int id, int time, int state )
{
    std::vector< std::vector< float > > auxFruits = levels[ id ].getPosFruits( );
    std::vector< std::vector < float > > auxSnake = levels[ id ].getPosSnake( );
    for( int i = 0 ; i < auxFruits.size( ) ; ++i )
    {
        if( auxSnake[ 0 ][ 0 ] == auxFruits[ i ][ 0 ] && auxSnake[ 0 ][ 1 ] == auxFruits[ i ][ 1 ] && auxSnake[ 0 ][ 2 ] == auxFruits[ i ][ 2 ] )
        {
            increment( id, state );
            levels[ i ].setScore( levels[ i ].getScore( ) + 1 );
            return 0;
        }
    }
    return time;
}
// ----------------------------------------------------------------------------
void ThreedController::increment( int id, int state )
{
    int aux = 0;
    if( state == 1 )
    {
        aux = levels[ id ].modifyOneI( );
    }
    if( state == 2 )
    {
        aux = levels[ id ].modifyTwoI( );
    }
    if( state == 3 )
    {
        aux = levels[ id ].modifyThreeI( );
    }
    if( state == 4 )
    {
        aux = levels[ id ].modifyFourI( );
    }
    return;
}
// ----------------------------------------------------------------------------
void ThreedController::setLevelDiff( int id, int diff )
{
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            levels[ i ].setDiff( diff );
        }
    }
}

// ----------------------------------------------------------------------------
void ThreedController::prepareObstacles( int id )
{
    for( int i = 0 ; i < levels.size( ) ; ++i )
    {
        if( levels[ i ].getId( ) == id )
        {
            std::vector< std::vector < float > > auxObstacles;
            std::vector< float > auxObstacle;
            std::vector< float > tam = levels[ i ].getSizeL( );
            float posX = 0;
            float posY = 0;
            float posZ = 0;
            if( id == -3 )
            {
                for( int i = 0 ; i < 50 ; ++i )
                {
                    posX = rand( ) % ( int )tam[ 0 ];
                    posZ = rand( ) % ( int )tam[ 2 ];
                    auxObstacle.push_back( posX );
                    auxObstacle.push_back( posY );
                    auxObstacle.push_back( posZ );
                    auxObstacles.push_back( auxObstacle );
                    auxObstacle.clear( );
                }
            }
            if( id == -4 )
            {
                for( int i = 0 ; i < 80 ; ++i )
                {
                    posX = rand( ) % ( int )tam[ 0 ];
                    posZ = rand( ) % ( int )tam[ 2 ];
                    auxObstacle.push_back( posX );
                    auxObstacle.push_back( posY );
                    auxObstacle.push_back( posZ );
                    auxObstacles.push_back( auxObstacle );
                    auxObstacle.clear( );
                }
            }
            if( id == -5 )
            {
                for( int i = 0 ; i < 150 ; ++i )
                {
                    posX = rand( ) % ( int )tam[ 0 ];
                    posZ = rand( ) % ( int )tam[ 2 ];
                    auxObstacle.push_back( posX );
                    auxObstacle.push_back( posY );
                    auxObstacle.push_back( posZ );
                    auxObstacles.push_back( auxObstacle );
                    auxObstacle.clear( );
                }
            }
            levels[ i ].setObstacles( auxObstacles );
            levels[ i ].setScore( 0 );
        }
    }
}
// ----------------------------------------------------------------------------
