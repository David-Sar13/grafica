// ----------------------------------------------------------------------------
//@author David Alberto Sarmiento Santamaria
//@brief So, this is our controller for Twod Screens
// ----------------------------------------------------------------------------

#include "TwodController.h"

// ----------------------------------------------------------------------------
TwodController::TwodController( )
{
}

// ----------------------------------------------------------------------------
TwodController::~TwodController( )
{
}

//Launch the Twod Main Set
// ----------------------------------------------------------------------------
void TwodController::receive( std::vector< std::vector< std::string > > dataF )
{
    int auxInt = 0;
    int val;
    for( int i = 0 ; i < dataF.size( ) ; ++i )
    {
        val = 5;
        std::vector< float > quads;
        std::vector< float > quadC;
        std::vector< int > sendTo;
        std::vector< std::string > text;
        TwodScreen aux;
        auxInt = std::stoi( dataF[ i ][ 0 ] );
        aux.SetId( auxInt );
        aux.SetColorP( std::stof( dataF[ i ][ 1 ] ), std::stof( dataF[ i ][ 2 ] ), std::stof( dataF[ i ][ 3 ] ) );
        auxInt = std::stoi( dataF[ i ][ 4 ] );
        aux.SetQuadQ( auxInt );

        for( int j = 0 ; j < auxInt ; ++j )
        {
            quads.push_back( std::stof( dataF[ i ][ val ] ) );
            quads.push_back( std::stof( dataF[ i ][ val + 1 ] ) );
            quads.push_back( std::stof( dataF[ i ][ val + 2 ] ) );
            quads.push_back( std::stof( dataF[ i ][ val + 3 ] ) );

            quadC.push_back( std::stof( dataF[ i ][ val + 4 ] ) );
            quadC.push_back( std::stof( dataF[ i ][ val + 5 ] ) );
            quadC.push_back( std::stof( dataF[ i ][ val + 6 ] ) );

            sendTo.push_back( std::stoi( dataF[ i ][ val + 7 ] ) );

            text.push_back( dataF[ i ][ val + 8 ] );

            val += 9;
        }
        aux.SetScreen( quads, quadC, sendTo, text );
        quads.clear( );
        quadC.clear( );
        sendTo.clear( );
        text.clear( );
        this->screens.push_back( aux );
    }
}

// ----------------------------------------------------------------------------
void TwodController::start( int id )
{
    glLoadIdentity( );
    drawScreen( id );
}
// ----------------------------------------------------------------------------
void TwodController::drawScreen( int id )
{
    int auxInt1 = 0;
    int auxInt2 = 0;
    int auxInt3 = 0;
    int auxX;
    int auxY;
    for( int i = 0 ; i < screens.size( ) ; ++ i )
    {
        if( screens[ i ].getId( ) == id )
        {
            std::vector< float > auxColorP = screens[ i ].getColorP( );
            std::vector< float > auxQuads = screens[ i ].getQuads( );
            std::vector< float > auxQuadC = screens[ i ].getQuadC( );
            std::vector< std::string > auxQuadText = screens[ i ].getQuadsText( );

            glLoadIdentity( );
            glColor3f( auxColorP[ 0 ], auxColorP[ 1 ], auxColorP[ 2 ] );
            glTranslated( 50, 50, 0 );
            glScaled( 100, 100, 1 );
            DrawSquare( GL_POLYGON );

            for( int j = 0 ; j < screens[ i ].getIQuadQ( ) ; ++j )
            {
                glLoadIdentity( );
                glTranslatef( ( ( auxQuads[ auxInt1 + 1 ] - auxQuads[ auxInt1 ] ) / 2 ) + auxQuads[ auxInt1 ], ( ( auxQuads[ auxInt1 + 3 ] - auxQuads[ auxInt1 +2 ] ) / 2 ) + auxQuads[ auxInt1 + 2 ], 0 );
                glScalef( auxQuads[ auxInt1 + 1 ] - auxQuads[ auxInt1 ] , auxQuads[ auxInt1 + 3 ] - auxQuads[ auxInt1 + 2 ], 1  );
                glColor3f( auxQuadC[ auxInt2 ], auxQuadC[ auxInt2 + 1 ], auxQuadC[ auxInt2 + 2 ] );
                DrawSquare( GL_POLYGON );
                if( auxQuadText[ auxInt3 ] != "." )
                {
                    outPut( ( ( ( auxQuads[ auxInt1 + 1 ] - auxQuads[ auxInt1 ] ) / 2 ) + auxQuads[ auxInt1 ] ) - ( auxQuadText[ auxInt3 ].size( ) / 2 ), ( ( ( auxQuads[ auxInt1 + 3 ] - auxQuads[ auxInt1 +2 ] ) / 2 ) + auxQuads[ auxInt1 + 2 ] ) - 0.5, auxQuadText[ auxInt3 ] );
                }
                //outPut( 50, 50, "hola" );
                auxInt1 += 4;
                auxInt2 += 3;
                ++auxInt3;
            }
        }
    }
}
// ----------------------------------------------------------------------------
void TwodController::DrawSquare( GLenum mode )
{
  glBegin( mode );
  {
    glVertex2f( -0.5, -0.5 );
    glVertex2f( -0.5,  0.5 );
    glVertex2f(  0.5,  0.5 );
    glVertex2f(  0.5, -0.5 );
  }
  glEnd( );
}
// ----------------------------------------------------------------------------
void TwodController::Listener( int button, int state, int x, int y )
{

}
// ----------------------------------------------------------------------------
std::pair< int, int > TwodController::checkFor2d( int xDo, int yDo, int xUp, int yUp, int id )
{
    std::pair< int, int > aux;
    int senderId;
    for( int i = 0 ; i < screens.size( ) ; ++i )
    {
        if( screens[ i ].getId( ) == id )
        {
            aux = screens[ i ].searchSender( xDo, yDo, xUp, yUp );
            return aux;
        }
    }
}
// ----------------------------------------------------------------------------
void TwodController::outPut( float x, float y, std::string text )
{
    //glPushMatrix( );
    glLoadIdentity( );
    glColor3f( 0.0, 0.0, 0.0 );
    glRasterPos3f( x, y, 0 );
    for( char c:text )
    {
        glutBitmapCharacter( GLUT_BITMAP_TIMES_ROMAN_24, c );
    }
    //glPopMatrix( );
}
// ----------------------------------------------------------------------------
void TwodController::setScore( int score )
{
    for( int i = 0 ; i < screens.size( ) ; ++i )
    {
        if( screens[ i ].getId( ) == 4 )
        {
            std::vector < std::string > aux = screens[ i ].getQuadsText( );
            std::string auxP = std::to_string( score );
            aux[ 1 ] = auxP;
            screens[ i ].setQuadsText( aux );
        }
    }
}
// ----------------------------------------------------------------------------
