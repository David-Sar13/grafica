/*
@brief This is our snake dudeeee. Sorry, i mean, professor
-------------------------------------------------------------------------------
@author David Albero Sarmiento Santamaría
@author Ediwn ALejandro Turizo Prieto
-------------------------------------------------------------------------------
Compilation on linux
g++ -o run Sarmiento_Turizo_Taller4.cxx -lGL -lGLU -lglut
-------------------------------------------------------------------------------
*/

#include <GL/glut.h>
#include <bits/stdc++.h>
#include "TwodController.h"
#include "ThreedController.h"

//-----------------------------------------------------------------------------
TwodController navegation2D;
ThreedController playGame;
int winId;
int winId3D;
int valCam = 0.5;
int actualScreen = 0;
int actualLevel = -2;
int stateM = 0;
int camS = 0;

int timeMl = 0;
int timeDiff = 10;
int diff = 0;

int xDo;
int yDo;
int xUp;
int yUp;
int auxIntCont = 0;

float camX = 0;
float camY = 0;
float camZ = 0;

float viewX = 0;
float viewY = 0;
float viewZ = 0;

std::vector< std::vector< float > > faces;
std::vector< std::vector< float > > normalV;
std::vector< std::vector< float > > vertex;

//-----------------------------------------------------------------------------
void RunGame2D( );
void RunGame3D( int id );
void prepareGame( int id);
void changeCam( int id );
void Init( );
void ResizeCbk2D( int width, int height );
void DisplayCbk2D( );
void ResizeCbk3D( int width, int height );
void DisplayCbk3D( );
void read2DScreens( );
void read3DLevels( );
void Begin ( int id );
void Play ( int id );
void MouseCbk2D( int button, int state, int x, int y );
void KeyboardCbk3D( unsigned char key, int x, int y );
int lookFor2d( int xDo, int yDo, int xUp, int yUp, int id );
void readObject( std::string fileN );

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
int main ( int argc, char* argv[ ] )
{
    readObject( "apple.obj" );
    read2DScreens( );
    read3DLevels( );
    glutInit( &argc, argv );
    RunGame2D( );
    //prepareGame( -2 );
    //RunGame3D( -2 );
    return( 0 );
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void RunGame2D( )
{
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB );
    glutInitWindowPosition( 100, 100 );
    glutInitWindowSize( 1000, 1000 );
    winId = glutCreateWindow( "SNAKE" );
    glutDisplayFunc( DisplayCbk2D );
    glutMouseFunc( MouseCbk2D );
    glutReshapeFunc( ResizeCbk2D );
    Init( );
    glutMainLoop( );
}

//-----------------------------------------------------------------------------
void Init( )
{
    glClearColor( 0.0, 0.0, 0.0, 0.0 );
}

// ----------------------------------------------------------------------------
void ResizeCbk2D( int width, int height )
{
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity( );
    glViewport( 0, 0, width, height );
    gluOrtho2D( 0, 100, 0, 100 );
}

// ----------------------------------------------------------------------------
void DisplayCbk2D( )
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity( );

    Begin( actualScreen );

    glutSwapBuffers( );
}

// ----------------------------------------------------------------------------
void read2DScreens( )
{
    std::vector< std::vector< std::string > > dataF;
    std::string line;
    std::string token;

    std::ifstream file;
    file.open( "screens2D.obj" );

    if( !file )
    {
        file.close( );
        throw std::runtime_error
        (
            std::string( "Error: No se pudo abrir el archivo ") + "screens2D.obj"
        );
    }
    int aux = 0;
    std::string state= "";

    std::vector < std::string > data;
    while( getline( file, line ) )
    {
        std::stringstream linestream( line );
        while( linestream >> token )
        {
            if( state == "p" && aux < 1 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 1 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "cp" && aux < 3 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 3 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            if( state == "qq" && aux < 1 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 1 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "qu" && aux < 4 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 4 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "cl" && aux < 3 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 3 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "ss" && aux < 1 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 1 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "tx" && aux < 1 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 1 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            if( token == "p" )
            {
                state = "p";
            }
            else if( token == "cp" )
            {
                state = "cp";
            }
            else if( token == "qq" )
            {
                state = "qq";
            }
            else if( token == "qu" )
            {
                state = "qu";
            }
            else if( token == "cl" )
            {
                state = "cl";
            }
            else if( token == "ss" )
            {
                state = "ss";
            }
            else if( token == "tx" )
            {
                state = "tx";
            }
            else if( token == "f" )
            {
                state = "f";
                dataF.push_back( data );
                data.clear( );
            }
        }
    }
    navegation2D.receive( dataF );
}
// ----------------------------------------------------------------------------
void Begin( int id )
{
    actualScreen = id;
    navegation2D.start( id );
}
// ----------------------------------------------------------------------------
void MouseCbk2D( int button, int state, int x, int y )
{
    int id;
    if( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
    {
        xDo = x;
        yDo = 1000 - y;
    }
    else if( button == GLUT_LEFT_BUTTON && state == GLUT_UP )
    {
        xUp = x;
        yUp = 1000 - y;

        id = lookFor2d( xDo, yDo, xUp, yUp, actualScreen );
        if( -1 > id )
        {
            glutDestroyWindow( winId );
            prepareGame( id );
            playGame.prepareObstacles( id );
            RunGame3D( id );
        }
        else if( id >= 0 )
        {
            actualScreen = id;
            glutPostRedisplay( );
        }
    }
}

// ----------------------------------------------------------------------------
int lookFor2d( int xDo, int yDo, int xUp, int yUp, int id )
{
    std::pair< int, int > aux;
    aux = navegation2D.checkFor2d( xDo, yDo, xUp, yUp, id );
    if( aux.second == 1 )
    {
        timeDiff = 80;
        diff = 1;
    }
    if( aux.second == 2 )
    {
        timeDiff = 40;
        diff = 2;
    }
    if( aux.second == 3 )
    {
        timeDiff = 10;
        diff = 3;
    }
    return aux.first;
}

// ----------------------------------------------------------------------------
void RunGame3D( int id )
{
    actualLevel = id;

    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB );
    glutInitWindowPosition( 100, 100 );
    glutInitWindowSize( 1000, 1000 );
    winId3D = glutCreateWindow( "SNAKE" );
    glutDisplayFunc( DisplayCbk3D );
    glutKeyboardFunc( KeyboardCbk3D );
    glutReshapeFunc( ResizeCbk3D );
    Init( );
    glutMainLoop( );
}

// ----------------------------------------------------------------------------
void ResizeCbk3D( int width, int height )
{
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity( );
    glViewport( 0, 0, width, height );
    gluPerspective(
        45,
        float( width ) / float( height ),
        3.1, 2000
    );
}

// ----------------------------------------------------------------------------
void DisplayCbk3D( )
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glMatrixMode( GL_MODELVIEW );

    // camera
    glLoadIdentity( );
    gluLookAt( camX, camY, camZ, viewX, viewY, viewZ, 0, 1, 0 );

    Play( actualLevel );

    glutSwapBuffers( );
}

// ----------------------------------------------------------------------------
void Play( int id )
{
    int aux = 0;
    std::pair< int, int > auxPair;
    auxPair.first = 0;
    auxPair.second = 0;
    //glPushMatrix( );
    playGame.setLevelDiff( id, diff );
    playGame.launchLevel( id );
    //glPopMatrix( );

    playGame.DisplayRound( id );

    auxPair = playGame.moveDaWorm( id, stateM );
    if( auxPair.first == 1 )
    {
        glutDestroyWindow( winId3D );
        timeMl = 0;
        stateM = 0;
        navegation2D.setScore( auxPair.second );
        actualScreen = 4;
        RunGame2D( );
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(timeDiff));

    ++timeMl;
    timeMl = playGame.sendFruit( actualLevel, timeMl, stateM );
    if( camS == 1 )
    {
        changeCam( actualLevel );
    }

    glutPostRedisplay( );
}

// ----------------------------------------------------------------------------
void read3DLevels( )
{
    std::vector< std::vector< std::string > > dataF;
    std::string line;
    std::string token;

    std::ifstream file;
    file.open( "levels3D.obj" );

    if( !file )
    {
        file.close( );
        throw std::runtime_error
        (
            std::string( "Error: No se pudo abrir el archivo ") + "levels3D.obj"
        );
    }
    int aux = 0;
    std::string state= "";

    std::vector < std::string > data;
    while( getline( file, line ) )
    {
        std::stringstream linestream( line );
        while( linestream >> token )
        {
            if( state == "l" && aux < 1 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 1 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "cl" && aux < 3 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 3 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "sl" && aux < 3 )
            {
                data.push_back( token );
                ++aux;
                if( aux == 3 )
                {
                    state = " ";
                    aux = 0;
                }
            }
            if( token == "l" )
            {
                state = "l";
            }
            else if( token == "cl" )
            {
                state = "cl";
            }
            else if( token == "sl" )
            {
                state = "sl";
            }
            else if( token == "f" )
            {
                state = "f";
                dataF.push_back( data );
                data.clear( );
            }
        }
    }
    playGame.receive( dataF );
}
// ----------------------------------------------------------------------------
void KeyboardCbk3D( unsigned char key, int x, int y )
{
    if( camS == 0 )
    {
        if( key == 'w')
        {
            if( stateM != 4 )
            {
                stateM = 3;
                glutPostRedisplay( );
            }
        }
        if( key == 's' )
        {
            if( stateM != 3 )
            {
                stateM = 4;
                glutPostRedisplay( );
            }
        }
        if( key == 'a')
        {
            if( stateM != 2 )
            {
                stateM = 1;
                glutPostRedisplay( );
            }
        }
        if( key == 'd' )
        {
            if( stateM != 1 )
            {
                stateM = 2;
                glutPostRedisplay( );
            }
        }
    }
    else if( camS == 1 )
    {
        if( key == 'a')
        {
            if( stateM == 1 )
            {
                stateM = 4;
                glutPostRedisplay( );
            }
            else if( stateM == 4 )
            {
                stateM = 2;
                glutPostRedisplay( );
            }
            else if( stateM == 2 )
            {
                stateM = 3;
                glutPostRedisplay( );
            }
            else if( stateM == 3 )
            {
                stateM = 1;
                glutPostRedisplay( );
            }
        }
        if( key == 'd' )
        {
            if( stateM == 1 )
            {
                stateM = 3;
                glutPostRedisplay( );
            }
            else if( stateM == 3 )
            {
                stateM = 2;
                glutPostRedisplay( );
            }
            else if( stateM == 2 )
            {
                stateM = 4;
                glutPostRedisplay( );
            }
            else if( stateM == 4 )
            {
                stateM = 1;
                glutPostRedisplay( );
            }
        }
    }

    if( key == 'p' )
    {
        valCam = 0.5;
        camS = 0;
        changeCam( actualLevel );
        glutPostRedisplay( );
    }
    if( key == 'l' )
    {
        valCam = 5.1;
        camS = 1;
        glutPostRedisplay( );
    }
}

// ----------------------------------------------------------------------------
void prepareGame( int id )
{
    std::vector < float > posCam;

    posCam = playGame.calculate( id );

    camX = posCam[ 0 ];
    camY = posCam[ 1 ];
    camZ = posCam[ 2 ];
    viewX = posCam[ 3 ];
    viewY = posCam[ 4 ];
    viewZ = posCam[ 5 ];
}
// ----------------------------------------------------------------------------
void changeCam( int id )
{
    std::vector < float > posCam;

    posCam = playGame.calculateDos( id, camS, stateM );

    camX = posCam[ 0 ];
    camY = posCam[ 1 ];
    camZ = posCam[ 2 ];
    viewX = posCam[ 3 ];
    viewY = posCam[ 4 ];
    viewZ = posCam[ 5 ];
}

// ----------------------------------------------------------------------------
void readObject( std::string fileN )
{
    faces.clear( );
    normalV.clear( );
    vertex.clear( );
    std::string line;
    std::string token;

    std::ifstream file;
    file.open( fileN );

    if( !file )
    {
        file.close( );
        throw std::runtime_error
        (
            std::string( "Error: No se pudo abrir el archivo ") + fileN
        );
    }
    int aux = 0;
    float parameter;
    std::string state = "";

    std::vector < float > auxV;
    while( getline( file, line ) )
    {
        std::stringstream linestream( line );
        while( linestream >> token )
        {
            if( state == "v" && aux < 3)
            {
                parameter = std::stof( token );
                auxV.push_back( parameter );
                ++aux;
                if( aux == 3 )
                {
                    vertex.push_back( auxV );
                    auxV.clear( );
                    state = " ";
                    aux = 0;
                }
            }
            if( state == "vn" && aux < 3)
            {
                parameter = std::stof( token );
                auxV.push_back( parameter );
                ++aux;
                if( aux == 3 )
                {
                    normalV.push_back( auxV );
                    auxV.clear( );
                    state = " ";
                    aux = 0;
                }
            }
            else if( state == "f" && aux < 3)
            {
                std::string delimiter = "//";
                size_t pos = 0;
                std::string auxToken;
                while( ( pos = token.find( delimiter ) ) != std::string::npos )
                {
                    auxToken = token.substr( 0, pos );
                    parameter = std::stof( auxToken );
                    parameter -= 1;
                    auxV.push_back( parameter );
                    token.erase( 0, pos + delimiter.length( ) );
                }
                parameter = std::stof( token );
                parameter -= 1;
                auxV.push_back( parameter );
                ++aux;
                if( aux == 3 )
                {
                    faces.push_back( auxV );
                    auxV.clear( );
                    state = " ";
                    aux = 0;
                }
            }
            if( token == "v")
            {
                state = "v";
            }
            else if( token == "f")
            {
                state = "f";
            }
            else if( token == "vn" )
            {
                state = "vn";
            }
        }
    }
    playGame.setVecsAp( faces, normalV, vertex );
    return;
}
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
